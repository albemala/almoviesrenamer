  IMDbPY's goodies
  ================

Useful shell scripts, especially for developers.
See the comments at the top of the files for usage and
configuration options.

applydiffs.sh: Bash script useful apply patches to a set of
IMDb's plain text data files.
You can use this script to apply the diffs files distributed
on a (more or less) weekly base by IMDb.

reduce.sh: Bash script useful to create a "slimmed down" version
of the IMDb's plain text data files.
It's useful to create shorter versions of the plain
text data files, to test the imdbpy2sql.py script faster.

