Please see cx_Freeze.html for documentation on how to use cx_Freeze.

To build:

python setup.py build
python setup.py install

